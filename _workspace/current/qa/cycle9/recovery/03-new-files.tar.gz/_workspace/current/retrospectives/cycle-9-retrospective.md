# Cycle 9 retrospective — 게임 흐름 개선

run-id: `20260728-onslaught-action-pivot`
cycle: 9
director: game-production-director
operating mode: Stage 2 re-entry — core-loop restructure + control feel
baseline commit: `033877ad` (PR #10 merged this cycle)

---

## 1. What the cycle was asked to do, and what actually happened

| # | Request | Outcome |
|---|---|---|
| 1 | 정해진 던전 · 웨이브 생성 · 웨이브 처치 | **Already existed.** Verified, not rebuilt. |
| 2 | 중간보스부터 추출 가능 | **Done.** `run.extractionUnlocked` flips on first midboss death; corpses gate on it. |
| 3 | 추출하여 군단을 꾸림 | **Done.** Corpse → 2 s channel → companion, ported into the live sim. |
| 4 | 기본 3, 최대 10 | **Mechanism done, reach short.** Capacity resolves dynamically 3→10; only **5** is affordable. See §4. |
| 5 | 레벨·비용지불 해금 | **Done.** Stage-clear gate + Bound Fragment cost per slot, shipped as data. |
| 6 | 에임에 맞는 타게팅 | **Done.** `AIM_BIAS_BP = 30000` weighting; bit-identical to nearest-enemy when no aim present. |
| 7 | 캐릭터별 공격 패턴 | **NOT done.** Deliberately deferred — see §5. |
| 8 | 가상키패드 → 가상조이스틱 | **Done, including portrait.** See §3. |
| 9 | 이동방향으로 바라보기 | **Already existed.** Verified only. |
| 10 | 카메라가 플레이어를 따라가기 | **Already existed.** Verified only. |
| 11 | 캐릭터 비율·크기 반영 | **Investigated, not changed.** See §5. |
| 12 | 스킬 이팩트 개선 | **Done.** Light-spear + ground-glow signatures, own budget. |
| 13 | UI 전면 개편 (open-design) | **Partly ceded.** See §6. |

Three requests turned out to be **already implemented** (1, 9, 10). Re-implementing
them would have been churn; they were verified against HEAD and closed.

---

## 2. Blocking defects found and fixed

All four were found by reading the deferred cycle-8 modules before integrating
them, not by testing afterwards.

| ID | Defect | Resolution | Proof |
|---|---|---|---|
| **D1** | Four module-level mutable counters generated entity IDs (`extraction-system.js:62,193`, `leveling-system.js:104,105`). Two runs of one seed in one process produced different IDs, breaking replay identity. | All ID sites moved to the run-scoped `nextId(run, kind)`. `Math.random()` never introduced. | gate E5: two same-seed runs both start at `nextId=0` |
| **D2** | Deferred design declared **all** enemies extractable; the requirement is midboss-onward. | `EXTRACTION_GRADE_BY_ENEMY` omits `normal` entirely — absence *is* the no-corpse rule, and it also bounds the corpse array. | gate E1/E2 |
| **D3** | `addCompanion()` had **no** capacity gate — a 4th companion could already be added mid-run at HEAD. | Gate added at the run-time checkpoint. | capacity tests 27–37 |
| **D4** | `getRunSnapshot()` serialises the **entire** commander object, so any new field enters `getRunDigest()` and breaks PR #10's depth-0 byte-identity. | Conditional presence on all four new fields, mirroring the existing `abyssDepth` pattern. | gate E7 + digest gate |

### The capacity blast radius — nine sites, two silent

The 3→10 feature was enforced in **nine** independent places, six of which were
not in the original plan. Full audit: `engineering/companion-capacity-blast-radius.md`.

Two failed **silently**:
- `defense-run-simulation.js:48` — `validLoadout` truncated to 3 at run creation with no error
- `app.js:1187` — the toggle handler dropped a 4th pick on click with no feedback

A change touching only `MAX_LOADOUT_SIZE` would have passed every simulation test
and been **dead in the product**. `app.js:1003`'s hardcoded `[0,1,2]` slot grid was
a third independent block: unlocked slots had nowhere to render.

### A pre-existing defect fixed incidentally

`app.js`'s lobby-cinematic companion row iterated `campaign.companionCollection`
as id strings, but it holds `{prototype, evolution, capturedEliteIds}` records
(enforced at `campaign-state.js:359`). Chips rendered
`data-companion="[object Object]"`, so that row **has never been able to deploy a
companion**. Present at HEAD; **not** caused by cycle 9.

---

## 3. Control feel: the misdiagnosis and the two gates

The request said "가상키패드는 가상조이스틱으로 변경". There was **no keypad**.
A joystick already existed — it simply **quantised to 8 octants**
(`JOYSTICK_OCTANTS`) and threw its precision away, so it *behaved* as a d-pad.

Fixing it required clearing **two independent gates**, and the second was nearly missed:

1. **JS gate** — `joystickActive()` required `(pointer: coarse) and (orientation: landscape)` *and* `data-defense-portrait !== "true"`. Both removed.
2. **CSS gate** — `.virtual-joystick { display: none }` was lifted **only** inside the landscape media query, every rule additionally scoped to `html[data-defense-portrait="false"]`. So a real coarse pointer in portrait still got a **0×0 box** and the JS gate correctly refused.

Widening the media query alone would not have worked. A portrait block was added
granting the box, copying the landscape visual values verbatim so the stick has
one visual language, and touching nothing in `.defense-bottom`'s locked grid.

Measured in a real browser at 390×844 with a real coarse pointer [OBSERVED]:

| Quantity | Value |
|---|---|
| Joystick box | `display:grid`, **116×116**, laid out |
| Analog magnitudes across a sweep | **563 → 966 → 1000** (continuous, not quantised) |
| Release | `analog "0,0"`, `move "IDLE"` |
| Fallback `[data-move]` buttons | 5 present, all **44×44** — no capability lost |
| Console/page errors | **0** |

### Why analog is digest-safe

`OCTANT_VECTORS` are integer millis at magnitude 1000 and movement is
`Math.trunc(v * speed / 1000 / TICK_RATE)`. Analog reuses that representation
exactly, so it is a **generalisation** of the octant table, not a parallel path.
Client-side `Math.trunc` guarantees the simulation never sees a float.

Two measured facts settled design questions that were otherwise guesswork:

- **No magnitude floor was shipped.** `getCommanderSpeed()` carries exactly one multiplier (occupation, **1.15**, an *increase*), so minimum reachable speed is **4100**. There, the dead zone (220) masks the truncation floor (15) by **14×**, and worst heading error is **0.79°**. A `Math.max(1,…)` guard would have been dead code. A test now asserts the speed floor so the assumption fails loudly if a slow is ever added.
- **Facing survives analog** at every live deflection, but the tightest margin is only **1.75×** over `MOVE_EPSILON` — the product of two constants in two files with no declared relationship. An enforced test now locks the derived relationship, matching the discipline applied to the speed guard.

`resetJoystick()` deserves specific credit: it also fires on blur/visibility-loss,
so an unguarded analog IDLE would have added `moveAnalog` to a **keyboard-only**
run and broken byte-identity — a path no synthetic probe exercises, because probes
never blur.

---

## 4. Gate table

Every verdict below carries a measured value, a method, and an evidence path.
**No gate is promoted on adjectives.**

| Gate | Verdict | Measured basis |
|---|---|---|
| **G1** 세계관 | **unchanged** | No player-visible lore/naming changed. Korean copy edits preserved existing voice. |
| **G2** 밸런스 | **not measured** | No combat number changed this cycle. 5–15 min pacing not re-measured. |
| **G3** 편성 다양성 | **FAIL — cannot PASS** | Capacity mechanism verified 3→10, but only **5** reachable. Best case: all stages cleared, **zero** equipment bought, 2 slots affordable, 3rd throws `Not enough Bound Fragment.` Ladder costs **16** cumulative against a lifetime pool of **10**. `pm/negotiation-record-cycle9-legion-capacity.md` |
| **G4** 몰입/접근성 | **not measured** | Requires human play (median ≥4.0/5). Automated evidence cannot substitute. Portrait stick verified functional, not *enjoyable*. |
| **G5** 매출 | **out of scope** | Declared out of scope. Options A/B in the negotiation record would make it a G5 item. |
| **G6** 운영/성능 | **partial** | VFX pool cap **24** intact; enrichment admitted under a **separate** budget so pool count no longer proxies frame cost; software-WebGL tier drops the glow (~85 % of fill) and keeps the spear. Worst-case VFX-storm measurement **incomplete** — the owning agent was aborted mid-measurement. |
| **G7** 코어 루프 | **not measured** | Loop shape changed (extraction is now a mid-run capability). Repeat-rate proxy ≥70 % needs human play. |
| **G8** 최초 노출 | **not measured** | New control scheme; learning curve needs human play. |

### Automated evidence [OBSERVED], all on a quiescent tree

| Gate script / suite | Result |
|---|---|
| `scripts/verify-cycle9-digest-identity.mjs` | **PASS** — seeds 1/17/4242 reproduce `58c20433…`, `1a6d4fd7…`, `1307786301…`; 26 commander keys; **zero fixtures edited** |
| `scripts/verify-cycle9-analog-live.mjs` | **PASS 6/6** — travel 4040/2040/1020 across full/half/quarter; full analog == octant exactly; 30° ≠ 45° |
| `scripts/verify-cycle9-extraction-live.mjs` | **PASS 8/8** — grade table, lock state, conditional presence, capacity clamp, run-scoped ids |
| `scripts/verify-cycle9-extraction-e2e.mjs` | **PASS 6/6** — the loop CLOSES in a real driven run: midboss dies at tick **3817** → `EXTRACTION_UNLOCKED` → `CORPSE_CREATED` (grade **SHADOW**, the correct midboss mapping) → channel 119/120 → `CORPSE_EXTRACTED` at tick **3936** → legion **0 → 1**. Interval 3936−3817 = **119**, matching `channelTicks: 120`. This is the only evidence that the headline feature works in *play* rather than at the API surface. |
| `scripts/verify-cycle9-portrait-joystick.cjs` | **SKIP on `main`** (exit 0, `merged: false`) — the CSS half is cycle 10's and not yet merged here. **PASS with the cutover applied**: box **116×116**, magnitudes **563 → 966 → 1000**, `failures: []`. Keys on the *cause* (reads `styles.css` for the cutover marker), so it skips honestly pre-merge and **fails** if visibility regresses post-merge. See §8. |
| `tests/campaign-state-rpg.test.mjs` | **37/37** (was 36/1 fail) — +11 tests, non-vacuity proven by a **14-mutant** matrix |
| `tests/defense-renderer-contract.test.mjs` + `combat-presentation-contract` | **51/51** — read-only invariant and 24-cap both intact |
| `world-presentation-contract` + `defense-public-contract-regressions` | **all pass** |
| Combined node suites | **103/103, 0 fail** |
| `tests/defense-hud-responsive-browser.cjs` | **`pass: true`** — portrait safe insets exactly `{11,17,29}` / `{23,17,29}` |

### The schema assertion was strengthened, not weakened

`tests/campaign-state-rpg.test.mjs:321` moved from `Object.keys(current).length === 16`
to a **sorted literal key-set** assertion of 17 keys. This is a contract change with
migration in place (`CURRENT_KEYS` carries the key, `migrateCampaign` defaults old
saves to 0), and it is **stronger**: mutant M16 showed a consistent rename keeps the
count at 17, so a count-only assertion passes blind while the key-set assertion
fails. The 17 keys are literals, **not** imported from `CURRENT_KEYS` — deriving
them from the schema would let a stray entry certify itself.

---

## 5. Deliberately not done

- **Per-character attack patterns (request 7).** The 12-weapon / 5-AoE / 6-hit-style catalog is in a deferred module with **zero imports** anywhere in the runtime or tests. Wiring it is its own slice; the live sim still resolves attacks as adjacent-melee-else-orb. Claiming this as done would have been false.
- **Character rescale (request 11).** No JS scale constants exist; scale is intrinsic to the GLB meshes. The reference frames actors at ≈7 % of viewport height and achieves player legibility through the over-head label and ground ring **rather than size** — so enlarging the mesh would copy the wrong solution. Investigated and left alone pending measurement.
- **Worst-case VFX-storm perf measurement.** Started, not finished; the agent was aborted. G6 is therefore *partial*, not PASS.

---

## 6. Process findings

### Concurrent sessions were the dominant risk, not the code

**Three** sessions wrote to this repository during the cycle:

1. **cycle 10** (`feat/cycle10-stage-dungeon`) — declared its own brief and an ownership table, ceding the analog input contract to cycle 9 and claiming UI/terrain/drops/audio.
2. **A third writer** — `battle-realtime-three.js` grew **698 → 970** lines *after* its owning agent was aborted, and `app.js` carries a foreign `DefenseAudio({sampleMapUrl})` edit. Symbols (`attachAoeBurst`, `AOE_BURST_SIGNATURES`) match `feat/motion-vfx-aoe-boss`.

This cost real time and produced one **false failure**: `defense-hud-responsive-browser.cjs`
timed out clicking `#start-defense` while the element was "visible, enabled and
stable". The tempting fix was the `force` click path already present in the test at
line 61. That would have hidden a genuine "player cannot start a run" defect behind
a green test. Diagnosis instead — `document.elementFromPoint` at the FAB centre
returned the FAB itself, overlap area **0** — proved the CSS was innocent, and the
test passed once the foreign write settled.

**Lesson**: before trusting any gate in a shared tree, establish quiescence
explicitly. Hash `git diff HEAD`, wait, hash again. All results in §4 were
re-run after `QUIESCENT` was confirmed.

### Boundary corrections cost less than boundary races

Two scope decisions were reversed mid-cycle when evidence contradicted them:

- HUD work was ceded to cycle 10, then the **lobby capacity enforcement** was taken back once it was clear those sites are *enforcement*, not presentation — otherwise the headline feature would have shipped unreachable.
- `styles.css` was ceded, then reclaimed once `git worktree list` showed cycle 10 works in a **separate** worktree with its own copy, so no collision was possible and the portrait cutover was one uncontested block away.

Both reversals were recorded in the brief rather than done silently.

### The digest baseline had to be captured before any edit

`qa/cycle9-digest-baseline.json` was captured at `033877ad` with **zero churn** on
all six source files — a window that existed for only a few minutes. Without it,
"byte-identity held" would have been an assertion rather than a measurement.

### Negative gates green-light dead features

The first verification gate written was negative: drive octant-only input, assert
nothing changed. It passes identically whether analog works or was never wired.
Three positive gates were added — and the load-bearing check is A3, deflection
scaling travel, because storing `analog` while still moving via the octant vector
passes both "field present" and "digest differs".

---

## 7. Next-cycle entry decision

**Enter at Stage 2, not Stage 1.** The concept and core loop are settled; what
remains is numeric and reach.

Ordered:

1. **Resolve the capacity budget** — `N-20260730-C9-01` needs a human owner decision. Recommended: Option C (reprice the ladder ≤6 cumulative, pure data change), fallback Option D (ship capacity 5 honestly). Until then **G3 cannot PASS**.
2. **Human play adjudication** for G4 / G7 / G8. These have been "재측정 필요" since cycle 8 and no automated result will move them.
3. **Finish the VFX-storm perf measurement** to close G6.
4. **Per-character attack patterns** as its own slice, wiring the deferred weapon catalog with the D1 counter fix applied first.
5. **Cycle 10 handoff**: `ui/battle-hud-concept-cycle9.md` stands as a design contract for them to consume — its player-job table and quality gate remain valid, its execution moved.

### Honest ledger

- `app.js` is **co-edited** by a foreign writer. Its cycle-9 half is verified but **not committed** — see §8. A hunk-selective staging filter was prepared and proven to apply cleanly (14 of 15 hunks, excluding the foreign `DefenseAudio` hunk), so the next session can land it without absorbing or destroying another session's work.
- `tests/defense-run-simulation.test.mjs` remains a **pre-existing** hang (SIGKILL/timeout), reproduced identically at unmodified HEAD in a clean worktree. Not a cycle-9 regression, and not resurrected here.
- The open-design generation loop was **not** run: no app on `:5173`, Darkbone-specific hard-rules doc absent, capture script expects a different game's five character rigs. Its *discipline* was adapted; **no** project id, run id, artifact SHA, or preview manifest was fabricated.

---

## 8. Commit status — NOTHING WAS COMMITTED [OBSERVED]

**Cycle 9 produced no commit.** The work is complete and verified in the working
tree; it is not in history. A verified-but-uncommitted change is not a shipped
change, and this section exists so no later reader mistakes one for the other.

### Why

CLAUDE.md §5 requires acquiring `/tmp/abyssal-surge-git-write.lock` with `mkdir`
and **"stop if it already exists."** It existed:

```
/tmp/abyssal-surge-git-write.lock/owner
owner=jeo-cycle10 session=dungeon-worktree      created 23:56:31
```

Still held after a further 200 s of waiting. The rule is a stop condition, not a
backoff hint, so staging was abandoned rather than raced. The cycle-10 session was
mid-commit on a tree we both occupy.

### What the next session must know to finish this

1. **`app.js` must be staged HUNK-SELECTIVELY.** It is co-edited. A prepared filter
   is reproducible: take `git diff HEAD -- app.js` (15 hunks), exclude the single
   hunk containing `DefenseAudio` (`@@ -1814,7 +1874,10 @@`, the foreign
   `sampleMapUrl` edit), and `git apply --cached` the remaining 14. Verified to
   apply cleanly. A plain `git add app.js` would absorb another session's
   in-progress work, which §5 forbids.
2. **Do not stage `scripts/generate-defense-audio.mjs`, `assets/audio/elevenlabs/`,
   `assets/audio/elevenlabs-sound-plan.json`, `defense-audio.js`, or
   `tests/audio-sample-hybrid.test.mjs`.** They belong to the audio writer and pair
   with the excluded `sampleMapUrl` hunk. Committing them piecemeal would land half
   of someone else's change.
3. **Do not stage `tests/aoe-burst-wide-hit-contract.test.mjs` or the AoE additions
   in `battle-realtime-three.js`** without checking ownership — `attachAoeBurst` /
   `AOE_BURST_SIGNATURES` appeared in this tree *after* the cycle-9 renderer agent
   was aborted and match `feat/motion-vfx-aoe-boss`. The cycle-9 renderer
   contribution is the range ring, corpse markers, extraction channel, and impact
   signatures.
4. **Cycle-9-owned paths, safe to stage as-is**: `defense-run-simulation.js`,
   `defense-catalog.js`, `campaign-state.js`, `styles.css` (portrait block only —
   97 added lines, uncontested in both worktrees), `tests/campaign-state-rpg.test.mjs`,
   `scripts/verify-cycle9-*.{mjs,cjs}`, and the `_workspace/current/` artifacts listed
   in §4.
5. **Re-establish quiescence first.** Hash `git diff HEAD`, wait, hash again, and
   only proceed on two equal hashes — then re-run the four gate scripts. Every
   number in §4 was measured on a quiescent tree and is invalid if the tree moved.

### Cycle-9 file inventory, for staging

| Path | Cycle-9 change | Staging note |
|---|---|---|
| `defense-run-simulation.js` | extraction, capacity gate, aim bias, analog acceptance | safe |
| `defense-catalog.js` | `EXTRACTION`, grade map, capacity constants, slot ladder, `AIM_BIAS_BP` | safe |
| `campaign-state.js` | `unlockedCompanionSlots`, capacity resolver, slot purchase, tamper validation | safe |
| `battle-realtime-three.js` | range ring, corpse markers, extraction channel, impact signatures | **mixed** — foreign AoE work also present |
| `app.js` | analog contract + 10 capacity sites + `[object Object]` fix | **hunk-selective**, exclude the `DefenseAudio` hunk |
| `styles.css` | portrait joystick block (+97) | **DROPPED — superseded by cycle 10 `d37b6568`.** Reverted; 0 churn. Do not stage, do not resurrect. |
| `tests/campaign-state-rpg.test.mjs` | schema key-set assertion + 11 tests | safe |
| `scripts/verify-cycle9-*.{mjs,cjs}` | **five** gate scripts: digest-identity, analog-live, extraction-live, extraction-e2e, portrait-joystick | safe, new files |

### Staging is an enumerated ALLOWLIST, not an exclusion list

The prose "do not stage X" guidance above is a **fallback explanation only**. The
authoritative artifact is:

- `_workspace/current/qa/cycle9-commit-pathspec.list` — machine-readable, use it
- `_workspace/current/qa/cycle9-commit-pathspec.txt` — the same list with the
  per-path rationale and the full omission register

```bash
git add --pathspec-from-file=_workspace/current/qa/cycle9-commit-pathspec.list
```

**Why an allowlist.** Three sessions wrote to this tree concurrently, and the
foreign set kept growing *while this retrospective was being written* — an
exclusion list is stale the moment a fourth path appears. Verified resolution
[OBSERVED]: `git add --dry-run` against the list yields exactly **24** paths, all
cycle-9, with **zero** foreign leaks.

The specific trap it defends: §8 item 4 previously said "`_workspace/current/`
artifacts are safe to stage". They are not. A `git add _workspace/current/qa/`
would absorb another session's regenerated `stage-runtime-proof/*.png` binaries
and a **−290 line** `stage-runtime-summary.json` rewrite. Cycle 9's artifacts under
that directory are only `cycle9-digest-baseline.json`, `cycle9/`, and the two
pathspec files.

`app.js`, `battle-realtime-three.js`, and `styles.css` are **deliberately absent**
from the allowlist — the first two need hunk/symbol-level splitting and the third
is superseded. They cannot be staged by accident through this file.

### Request #8 needs BOTH halves — do not land one without the other

Cycle 10 shipped `d37b6568` ("make the virtual joystick the primary movement
control everywhere") at 00:06 while this cycle was verifying. It deletes the
`.virtual-joystick { display: none; }` default and the
`(pointer: coarse) and (orientation: landscape)` + `data-defense-portrait` gating,
replacing them with the same non-zero-rect capability test. Its message states
plainly: *"The analog contract belongs to the concurrent session's cycle 9 and is
deliberately not implemented here."*

So the two halves are complementary, and **neither alone answers the request**:

| Half | Owner | Status |
|---|---|---|
| CSS visibility — stick has a box at every viewport | **cycle 10** | shipped in `d37b6568` |
| Continuous analog payload — stick stops quantising | **cycle 9 (this cycle)** | in this tree, uncommitted |

Measured [OBSERVED]: cycle 10's branch contains `moveAnalog` **0** times and
`defenseMoveAnalog` **0** times in `app.js`, and `moveAnalog` **0** times in
`defense-run-simulation.js`. This tree has 4 in the sim and 3 in `app.js`.

**Consequence if only cycle 10 lands**: the stick becomes prominent and primary
**while still emitting 8 quantised octants** — it promotes the exact d-pad
behaviour the request asked to remove. That is a worse outcome than before, because
the control is now the primary one.

Verified together [OBSERVED 2026-07-30]: cycle 10's `styles.css` swapped into this
tree's analog `app.js` yields `ok: true`, box **116×116**, magnitudes
**563 → 966 → 1000**. The halves compose correctly.

`scripts/verify-cycle9-portrait-joystick.cjs` is retained as the regression gate and
keys on the **cause**, not the symptom: it reads `styles.css` for the cutover marker
and SKIPS with an explicit pending-merge reason when absent (green on `main`), then
runs real assertions once merged. If the cutover lands and portrait visibility later
regresses, it **fails** rather than silently skipping — the failure mode a
symptom-keyed skip would have hidden.

**`app.js` conflict warning**: cycle 10 rewrote the same `joystickActive()` and
`updateJoystick()` call sites. The hunk-selective recipe above was derived against
`033877ad` and **must be re-derived against their branch**, not reused verbatim.
